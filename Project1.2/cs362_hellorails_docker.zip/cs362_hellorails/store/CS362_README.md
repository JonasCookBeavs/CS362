This is a placeholder file so that the directory will be created from
the ZIP.

See the README.md in the parent directory for more info.
