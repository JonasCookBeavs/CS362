docker compose run --service-ports --rm cs362-hellorails bash
